function NotFound() {
  return <p>Brak strony</p>;
}

export default NotFound;


